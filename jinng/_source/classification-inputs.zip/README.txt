Public evidence classification reproduction
Install Python packages: shapely pyproj
Run: python functional_classification/scripts/classify.py
No keys included. No network is needed to rebuild. The optional fetch script is capped at 6 attempts; the bundled ledger has already reached this cap.
OSM data and derived functional database: ODbL; Overture Places: see upstream source records and https://docs.overturemaps.org/guides/places/
Original building footprints: https://zenodo.org/records/8174931 (CC BY 4.0), via Overture. GBA.Height-derived values: CC BY-NC 4.0.
