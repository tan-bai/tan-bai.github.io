"""Reproducible, conservative functional hypotheses; never ground-truth labels.

Run from project root: .venv/bin/python functional_classification/scripts/classify.py
Coordinates: WGS84 inputs -> EPSG:32650 local metres. No web requests or keys.
"""
import collections
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from pyproj import Transformer
from shapely import make_valid
from shapely.geometry import Point, Polygon, box, mapping
from shapely.ops import transform
from shapely.strtree import STRtree

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'functional_classification'
CATEGORIES = {
    'residential': ('居住', '#e3b73e'),
    'commercial': ('商业服务', '#df7255'),
    'culture': ('文化旅游 / 宗教', '#9a76c6'),
    'public': ('教育医疗 / 公共服务', '#458fc4'),
    'recreation': ('公园休闲', '#63a66f'),
    'industrial': ('工业仓储', '#9d7b5c'),
    'transport': ('交通设施', '#688794'),
    'mixed': ('混合线索', '#d995bb'),
    'unknown': ('待核验', '#c3c7ca'),
}
BOUNDS = box(-800, -800, 800, 800)
PROJECT = Transformer.from_crs(4326, 32650, always_xy=True)


def osm_category(t):
    tourism, amenity = t.get('tourism'), t.get('amenity')
    if tourism in {'museum','attraction','gallery','viewpoint','information'} or t.get('historic') in {'building','castle','monument','memorial','city_gate','archaeological_site'} or amenity == 'place_of_worship':
        return 'culture'
    if amenity in {'school','university','college','kindergarten','hospital','clinic','library','townhall','police','fire_station','post_office','community_centre'} or t.get('office') == 'government':
        return 'public'
    if t.get('leisure') in {'park','garden','playground','sports_centre','stadium','pitch'}:
        return 'recreation'
    if amenity in {'parking','bus_station','ferry_terminal'} or t.get('public_transport') == 'station':
        return 'transport'
    if t.get('landuse') in {'industrial','garages'} or t.get('building') in {'industrial','warehouse'}:
        return 'industrial'
    if t.get('landuse') in {'residential'} or t.get('building') in {'residential','apartments','house','dormitory','terrace','detached'}:
        return 'residential'
    if t.get('landuse') in {'commercial','retail'} or t.get('shop') or t.get('office') or tourism in {'hotel','hostel','guest_house','motel'} or amenity in {'restaurant','cafe','fast_food','bar','marketplace','bank'} or t.get('building') in {'retail','commercial','office'}:
        return 'commercial'


def place_category(p):
    h = set((p.get('taxonomy') or {}).get('hierarchy') or [])
    if h & {'historic_site','museum','place_of_worship','religious_organization','cultural_and_historic'}:
        return 'culture'
    if h & {'hospital','clinic','school','university','government_office','library'}:
        return 'public'
    if h & {'park','garden','sports_centre'}:
        return 'recreation'
    if h & {'food_and_drink','shopping','lodging','hotel','restaurant','corporate_or_business_office'}:
        return 'commercial'
    # A company point or manufacturer address does not establish an industrial site.
    return None


def polygons(g):
    if g.geom_type == 'Polygon':
        yield g
    elif hasattr(g, 'geoms'):
        for part in g.geoms:
            yield from polygons(part)


def build(city, source):
    scene_path = ROOT / source / 'data/scene.json'
    scene = json.loads(scene_path.read_text())
    origin = scene['metadata']['origin_utm']
    def xy(lon, lat):
        x,y = PROJECT.transform(float(lon), float(lat))
        return x-origin[0], y-origin[1]
    xml_path = ROOT / source / 'data/raw/osm_map.xml'
    xml = ET.parse(xml_path).getroot()
    nodes = {n.attrib['id']: xy(n.attrib['lon'],n.attrib['lat']) for n in xml.findall('node')}
    zones, pois, rejected = [], [], []
    for kind in ['way','node']:
        for item in xml.findall(kind):
            tags = {t.attrib['k']: t.attrib['v'] for t in item.findall('tag')}
            category = osm_category(tags)
            if not category: continue
            rec = {'id':f"osm/{kind}/{item.attrib['id']}", 'name':tags.get('name', ''), 'category':category, 'source':'OpenStreetMap', 'tags':tags}
            if kind == 'way':
                refs=[n.attrib['ref'] for n in item.findall('nd')]
                if len(refs)<4 or refs[0]!=refs[-1] or any(n not in nodes for n in refs): continue
                geom=make_valid(Polygon([nodes[n] for n in refs])).intersection(BOUNDS)
                for part in polygons(geom):
                    if part.area>1: zones.append({**rec,'geom':part,'direct_building':bool(tags.get('building'))})
            else:
                point=Point(nodes[item.attrib['id']])
                if BOUNDS.covers(point): pois.append({**rec,'geom':point})
    # Relevant relations in these cached extracts are not functional polygons.
    relevant_relations=[r.attrib['id'] for r in xml.findall('relation') if osm_category({t.attrib['k']:t.attrib['v'] for t in r.findall('tag')})]
    if relevant_relations: raise RuntimeError(f'Functional multipolygon relations need parsing: {relevant_relations}')
    places_path=WORK / f'data/raw/{city}_places.geojson'
    raw_places=json.loads(places_path.read_text())['features']
    coord_counts=collections.Counter(tuple(round(v,6) for v in f['geometry']['coordinates']) for f in raw_places)
    for f in raw_places:
        p=f['properties']; coords=f['geometry']['coordinates']; point=Point(xy(*coords))
        category=place_category(p); name=(p.get('names') or {}).get('primary','')
        rec={'id':f"overture/place/{p.get('id', f.get('id',''))}",'name':name,'category':category,'source':'Overture Places 2026-10-21.0','tags':{'basic_category':p.get('basic_category'),'taxonomy':(p.get('taxonomy') or {}).get('primary')}}
        reason=None
        if not BOUNDS.covers(point): reason='outside_sample'
        elif coord_counts[tuple(round(v,6) for v in coords)]>=3: reason='shared_coordinate_3_or_more_records'
        elif p.get('operating_status') in {'permanently_closed','closed'}: reason='closed'
        elif p.get('confidence') is not None and p['confidence']<.7: reason='low_existence_confidence'
        elif not category: reason='category_does_not_establish_local_function'
        elif any(w in name.lower() for w in ['manufacturer','drilling','equipment','machinery']) and category in {'commercial','public'}: reason='name_category_or_facility_uncertain'
        if reason: rejected.append({**rec,'reason':reason}); continue
        if any(q['category']==category and q['geom'].distance(point)<15 for q in pois):
            rejected.append({**rec,'reason':'near_duplicate_same_category'});continue
        pois.append({**rec,'geom':point})
    buildings=[f for f in scene['features'] if f['kind']=='building']
    geoms=[make_valid(Polygon(b['rings'][0], b['rings'][1:])) for b in buildings]
    tree=STRtree(geoms)
    poi_matches=collections.defaultdict(list)
    for p in pois:
        matches=tree.query(p['geom'].buffer(12))
        distances=sorted((geoms[i].distance(p['geom']),int(i)) for i in matches)
        if not distances: continue
        distance,i=distances[0]
        if distance>12:continue
        # Neighbourhood points do not label several blocks. Ambiguous matches excluded.
        if len(distances)>1 and distances[1][0]-distance<3:
            rejected.append({'id':p['id'],'name':p['name'],'reason':'ambiguous_building_match'});continue
        poi_matches[i].append({k:v for k,v in p.items() if k!='geom'}|{'method':'POI 点位推断' if distance==0 else '邻近 POI 推断','distance_m':round(distance,1)})
    records=[]
    for i,(b,g) in enumerate(zip(buildings,geoms)):
        evidence=[]
        for z in zones:
            if not z['geom'].intersects(g):continue
            ratio=z['geom'].intersection(g).area/g.area
            if ratio<.5:continue
            evidence.append({k:v for k,v in z.items() if k not in {'geom','direct_building'}}|{'method':'OSM 建筑标签' if z['direct_building'] else 'OSM 区域归属推断','overlap':round(ratio,3),'priority':3 if z['direct_building'] else 2,'zone_area_m2':round(z['geom'].area)})
        # Small explicit sites override encompassing broad residential areas; disagreements remain visible.
        evidence.sort(key=lambda e:(-e['priority'],e['zone_area_m2']))
        chosen=evidence[0]['category'] if evidence else 'unknown'
        level='区域推断' if evidence else '待核验'
        if evidence and evidence[0]['priority']==3:level='建筑标签'
        point_evidence=poi_matches[i]
        point_categories={e['category'] for e in point_evidence}
        if point_categories:
            if chosen=='unknown':
                chosen=next(iter(point_categories)) if len(point_categories)==1 else 'mixed';level='点位推断'
            elif any(c!=chosen for c in point_categories):
                chosen='mixed';level='混合线索'
        records.append({'id':b['id'],'name':b.get('name',''),'category':chosen,'evidence_level':level,'height_m':b['height_m'],'height_method':b.get('height_method'),'area_m2':round(g.area,2),'evidence':evidence+point_evidence})
    counts=collections.Counter(r['category'] for r in records)
    area_counts={k:round(sum(r['area_m2'] for r in records if r['category']==k),1) for k in CATEGORIES}
    report={'city':city,'version':'functional-v1','created':'2026-11-09','crs':'EPSG:32650','origin_utm':origin,'building_count':len(records),'classified_count':len(records)-counts['unknown'],'counts':dict(counts),'footprint_area_m2':area_counts,'osm_zone_count':len(zones),'public_places_downloaded':len(raw_places),'usable_poi_count':len(pois),'matched_building_count':sum(bool(v) for v in poi_matches.values()),'rejected_poi_records':rejected,'tianditu_calls':0,'method':'公开标签 + 区域叠置（建筑面积重叠至少 50%）+ POI 点位（至多 12 米且排除歧义）。非神经网络、非官方用地、非逐栋核验。','limitations':['区域标签是建筑功能线索，不等于逐栋用途；POI 代表设施点位，不代表整个地块。','无依据保留待核验，冲突标为混合线索；分类完整度不等于准确率。','Google Earth 只作平面与外观参照，不据屋顶颜色猜测功能。','建筑几何、估计高度与影像保持原版本，数据年份不同。'],'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [scene_path,xml_path,places_path]}}
    data={'metadata':report,'categories':{k:{'label':v[0],'color':v[1]} for k,v in CATEGORIES.items()},'buildings':records,'zones':[{'id':z['id'],'name':z['name'],'category':z['category'],'source':z['source'],'rings':[[[round(x,2),round(y,2)] for x,y in ring.coords] for ring in [z['geom'].exterior,*z['geom'].interiors]]} for z in zones]}
    ledger_path=WORK/'data/raw/sdmap_usage.json'
    if ledger_path.exists():
        ledger=json.loads(ledger_path.read_text())
        report['tianditu_calls']=sum(r['city']==city for r in ledger['requests'])
        report['tianditu_calls_total']=ledger['request_count']
        report['tianditu_result']='浏览器端 key 直连认证成功，但两个样方空间查询均返回 0 条；未加入任何山东 POI。已达到本轮 6 次上限，停止查询。'
        report['tianditu_source_used']=False
    # Jining's context is a single mesh. Separate prism layer preserves all source footprints.
    if city=='jinng':
        data['geometry']=[{'id':b['id'],'height_m':b['height_m'],'rings':b['rings'],'triangles':b['triangles']} for b in buildings]
    out=WORK/'output';out.mkdir(exist_ok=True)
    (out/f'{city}_functions.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
    (out/f'{city}_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    inverse=Transformer.from_crs(32650,4326,always_xy=True)
    def to_wgs(x,y,z=None): return inverse.transform(x+origin[0],y+origin[1])
    features=[{'type':'Feature','geometry':mapping(transform(to_wgs,g)),'properties':r} for r,g in zip(records,geoms)]
    (out/f'{city}_functions.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,separators=(',',':')))
    print(city, json.dumps({k:report[k] for k in ['building_count','classified_count','counts','osm_zone_count','usable_poi_count','matched_building_count']},ensure_ascii=False))


if __name__=='__main__':
    build('jinng','reconstruction')
    build('qufu','reconstruction_qufu_gba')
