"""Capped official POI queries. Key is read silently, never stored or logged.
Bind the active physical interface to bypass the local singbox TUN.
"""
import argparse, getpass, json, subprocess
from pathlib import Path
from urllib.parse import urlencode
from pyproj import Transformer

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'functional_classification/data/raw'
LEDGER=OUT/'sdmap_usage.json'
args=argparse.ArgumentParser()
args.add_argument('--page',type=int,default=1)
args.add_argument('--interface',default='wlp6s0')
args.add_argument('--retry-errors',action='store_true')
args.add_argument('--retry-empty',action='store_true')
options=args.parse_args()
ledger=json.loads(LEDGER.read_text()) if LEDGER.exists() else {'api':'Shandong LocalSearch','request_count':0,'session_cap':6,'requests':[]}
key=getpass.getpass('Shandong tk (not saved): ')
inverse=Transformer.from_crs(32650,4326,always_xy=True)
for city,source in [('jinng','reconstruction'),('qufu','reconstruction_qufu_gba')]:
    destination=OUT/f'{city}_sdmap_page{options.page}.json'
    if destination.exists():
        cached=json.loads(destination.read_text())
        retry_error=options.retry_errors and isinstance(cached,dict) and cached.get('code')==301012
        retry_empty=options.retry_empty and isinstance(cached,dict) and cached.get('status')=='ok' and not cached.get('result',{}).get('features')
        if not (retry_error or retry_empty):
            print(city,'cached; no request');continue
    if ledger['request_count']>=ledger['session_cap']:raise SystemExit('Request cap reached')
    meta=json.loads((ROOT/source/'data/scene.json').read_text())['metadata'];ox,oy=meta['origin_utm']
    ring=[inverse.transform(ox+x,oy+y) for x,y in [(-800,-800),(800,-800),(800,800),(-800,800),(-800,-800)]]
    area='POLYGON(('+','.join(f'{x:.8f} {y:.8f}' for x,y in ring)+'))'
    query={'st':'LocalSearch','city':'全国','area':area,'category':'f_poi','page':options.page,'pagecap':500,'tk':key}
    if options.retry_empty:
        query['city']='济宁' if city=='jinng' else '曲阜'
        query.pop('category')
    ledger['request_count']+=1;ledger['requests'].append({'city':city,'page':options.page,'pagecap':500,'city_filter':query['city'],'category_filter':query.get('category')})
    LEDGER.write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
    # URL is passed via stdin, not argv or disk. No automatic retries/redirects.
    config='url = "https://service.sdmap.gov.cn/search?'+urlencode(query)+'"\n'
    result=subprocess.run(['curl','--noproxy','*','--interface',options.interface,'--connect-timeout','10','--max-time','30','-sS','--referer','https://www.sdmap.gov.cn/','--user-agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/142.0.0.0 Safari/537.36','--config','-'],input=config,capture_output=True,text=True)
    safe=result.stdout.replace(key,'[redacted]')
    try:data=json.loads(safe)
    except Exception:
        print(city,'non-JSON response; stopped',result.returncode,'requests',ledger['request_count']);break
    destination.write_text(json.dumps(data,ensure_ascii=False))
    print(city,'root keys',list(data) if isinstance(data,dict) else type(data).__name__)
    if isinstance(data,dict):
        print('counts / status:',{k:v for k,v in data.items() if isinstance(v,(int,float,str)) and len(str(v))<100})
        print('lists:',{k:len(v) for k,v in data.items() if isinstance(v,list)})
        if data.get('code') and data.get('msg'):break
print('Total requests:',ledger['request_count'])
